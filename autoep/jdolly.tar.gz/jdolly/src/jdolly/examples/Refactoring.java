package jdolly.examples;

public enum Refactoring {
	RENAME_CLASS,RENAME_METHOD,PUSH_DOWN_METHOD

}
