package jdolly.filters;

public class Filter {

}
