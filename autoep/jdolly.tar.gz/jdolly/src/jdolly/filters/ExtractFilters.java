package jdolly.filters;

import java.util.List;

import edu.mit.csail.sdg.alloy4compiler.translator.A4Solution;

public class ExtractFilters {

	

//	public static List<Filter> extract(A4Solution alloySolution) {
//		// TODO Auto-generated method stub
//		
//	}

}
